package Assignments;

public class Prog1 {
    public static void main(String[] args) {
      //  RandomNumbers num = new RandomNumbers();
        int x = RandomNumbers.getRandomInt(0, 9);
        System.out.println(Math.PI * x);
        int y = RandomNumbers.getRandomInt(3,14);
        System.out.println(y*Math.PI);
    }
}
